#include <Adafruit_MLX90614.h>
#include <DMD2.h>
#include <SPI.h>
#include <fonts/SystemFont5x7.h>
#include <Wire.h>

// ======= Sensor & Display =======
Adafruit_MLX90614 mlx = Adafruit_MLX90614();
SoftDMD dmd(1, 1);

// ======= Konfigurasi =======
const int Standard             = 25;
const int TEMP_MIN             = 2;
const int TEMP_MAX             = 60;
const unsigned long INTERVAL_READ  = 1000;

// ======= Variabel State =======
unsigned long lastReadTime    = 0;
int memory                    = 25;
int lastDisplayedTemp         = -999;

char tempBuf[6];
char svBuf[6];

void setup() {
  Serial.begin(9600);
  Serial.println("== Monitoring System Boot ==");

  // 1. Inisialisasi DMD (P10)
  dmd.begin();
  dmd.setBrightness(130);
  dmd.selectFont(SystemFont5x7);
  dmd.clearScreen();

  // Tampilan Header Statis
  dmd.drawString(2,  0, "SV");
  dmd.drawString(19, 0, "PV");
  itoa(Standard, svBuf, 10);
  dmd.drawString(2,  9, svBuf);
  dmd.drawString(19, 9, "--");

  // 2. Inisialisasi I2C dengan Clock Rendah (Anti-Noise)
  Wire.begin();
  Wire.setClock(50000); 

  // 3. Init MLX90614
  if (!mlx.begin()) {
    Serial.println("ERROR: MLX90614 Tidak Terdeteksi!");
    dmd.clearScreen();
    dmd.drawString(2, 4, "ERR-MLX");
    // Tidak pakai while(1) agar sistem tidak mati total
  } else {
    Serial.println("MLX90614 OK");
  }
}

void loop() {
  unsigned long currentMillis = millis();

  // Baca Sensor & Update Display setiap 1 detik
  if (currentMillis - lastReadTime >= INTERVAL_READ) {
    lastReadTime = currentMillis;

    float tempReading = mlx.readObjectTempC();
    
    // Validasi Dasar (Cegah angka loncat karena noise I2C)
    if (isnan(tempReading) || tempReading < -20 || tempReading > 120) {
      Serial.println("Pembacaan sensor tidak valid.");
      return; 
    }

    int temp = (int)tempReading;

    // Filter Rentang
    if (temp >= TEMP_MIN && temp <= TEMP_MAX) {
      memory = temp;
    } else {
      temp = memory;
    }

    // Update display hanya jika ada perubahan angka
    if (temp != lastDisplayedTemp) {
      lastDisplayedTemp = temp;

      // Bersihkan area angka PV (x=19 sampai 31)
      dmd.drawFilledBox(19, 9, 31, 15, GRAPHICS_OFF);

      itoa(temp, tempBuf, 10);
      dmd.drawString(19, 9, tempBuf);

      Serial.print("Update PV: ");
      Serial.println(temp);
    }
  }
}
