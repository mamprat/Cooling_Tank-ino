#include <OneWire.h>
#include <DallasTemperature.h>
#include <DMD2.h>
#include <SPI.h>
#include <fonts/SystemFont5x7.h>

// ======= Konfigurasi Sensor DS18B20 =======
#define ONE_WIRE_BUS 4
OneWire oneWire(ONE_WIRE_BUS);
DallasTemperature sensors(&oneWire);

// ======= Konfigurasi Display P10 =======
SoftDMD dmd(1, 1); 

// ======= Konstanta & Variabel =======
const int Standard = 25;
const int TEMP_MIN = 2;
const int TEMP_MAX = 60;
const unsigned long INTERVAL_READ = 2000; 

unsigned long lastReadTime = 0;
int memory = 25; // Default ke 25 jika bacaan awal gagal
int lastDisplayedTemp = -999;

char tempBuf[6];
char svBuf[6];

void setup() {
  Serial.begin(9600);
  
  // 1. Inisialisasi DMD
  dmd.begin();
  dmd.setBrightness(130);
  dmd.selectFont(SystemFont5x7);
  dmd.clearScreen();

  // 2. Inisialisasi Sensor
  sensors.begin();
  
  // 3. Tampilan Statis (Header)
  dmd.drawString(2,  0, "SV");
  dmd.drawString(19, 0, "PV");
  
  itoa(Standard, svBuf, 10);
  dmd.drawString(2,  9, svBuf);
  dmd.drawString(19, 9, "--"); // Tanda awal sebelum baca suhu
}

void loop() {
  unsigned long currentMillis = millis();

  // Pembacaan Suhu Berkala
  if (currentMillis - lastReadTime >= INTERVAL_READ) {
    lastReadTime = currentMillis;

    sensors.requestTemperatures();
    float tempReading = sensors.getTempCByIndex(0);
    
    // Proteksi jika sensor lepas/error
    if (tempReading == DEVICE_DISCONNECTED_C) {
      Serial.println("Error: Sensor DS18B20 Terputus!");
      dmd.drawFilledBox(19, 9, 31, 15, GRAPHICS_OFF);
      dmd.drawString(19, 9, "??"); 
      return; 
    }

    int temp = (int)tempReading;

    // Validasi Range Suhu
    if (temp >= TEMP_MIN && temp <= TEMP_MAX) {
      memory = temp;
    } else {
      temp = memory; // Gunakan nilai terakhir jika di luar range
    }

    // Update display hanya jika ada perubahan angka (mencegah flicker)
    if (temp != lastDisplayedTemp) {
      lastDisplayedTemp = temp;
      
      // Bersihkan area angka PV saja
      dmd.drawFilledBox(19, 9, 31, 15, GRAPHICS_OFF); 
      
      itoa(temp, tempBuf, 10);
      dmd.drawString(19, 9, tempBuf);
      
      Serial.print("Suhu PV: ");
      Serial.println(temp);
    }
  }
}
